import Game from './game/game.class.js';

const game = new Game(document.getElementById('canvas'));